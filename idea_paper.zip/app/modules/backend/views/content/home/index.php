<div class="row">
    <div class="col-md-12 grid-margin">
      <div class="row">
        <div class="col-12 col-xl-5 mb-4 mb-xl-0">
          <h4 class="font-weight-bold">Hi, Welcome!</h4>
          <h4 class="font-weight-normal mb-0"><?=profile("nama")?></h4>
        </div>
      </div>
    </div>
</div>
