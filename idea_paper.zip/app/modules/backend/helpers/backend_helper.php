<?php defined('BASEPATH') OR exit('No direct script access allowed');

if ( ! function_exists('sess'))
{
  function sess($str)
  {
     $ci=& get_instance();
    return $ci->session->userdata($str);
  }
}


function config_all($where,$field)
{
  $ci=& get_instance();
  $query = $ci->db->where($where)
                  ->get("config_all")
                  ->row();
  return $query->$field;
}

if ( ! function_exists('profile'))
{
  function profile($field)
  {
     $ci=& get_instance();
     $query = $ci->db->get_where("tb_admin",['id_admin'=>$ci->session->userdata('id_admin')]);
     if ($query->num_rows()> 0) {
       return $query->row()->$field;
     }else {
       return "Error Helper";
     }
  }
}


if ( ! function_exists('profile_where'))
{
  function profile_where($id,$field)
  {
     $ci=& get_instance();
     $query = $ci->db->get_where("tb_admin",['id_admin'=>$id]);
     if ($query->num_rows()> 0) {
       return $query->row()->$field;
     }else {
       return "Error Helper";
     }
  }
}


if ( ! function_exists('profile_member'))
{
  function profile_member($id,$field)
  {
     $ci=& get_instance();
     $query = $ci->db->get_where("tb_person",['id_person'=>$id]);
     if ($query->num_rows()> 0) {
       return $query->row()->$field;
     }else {
       return "Error Helper";
     }
  }
}

if ( ! function_exists('format_rupiah'))
{
  function format_rupiah($int)
  {
    return number_format($int, 0, ',', '.');
  }
}


function select_bank($id_bank)
{
  $str = "";
  $ci = get_instance();
  $query = $ci->db->get('ref_bank');
            foreach ($query->result() as $row) {
              $str .="<option value='".$row->id_bank."'";
              $str .= ($row->id_bank===$id_bank) ? "selected" : '';
              $str .=">".$row->inisial_bank."</option>";
            }
  return $str;
}

function wilayah_indonesia($table,$where){

  $ci = get_instance();
  $query =  $ci->db->get_where($table,$where);
  if ($query->num_rows() > 0) {
      return $query->row()->name;
  }else {
    return "data wilayah tidak di temukan";
  }

}

// menampilkan wilayah berdasarkan table dan id
function tampilkan_wilayah($table,$where,$selected)
{
  $ci=get_instance();
  $str="";
  $query = $ci->db->get_where($table,$where);
  if ($query->num_rows() > 0) {
      foreach ($query->result() as $row) {
        $str .= '<option value="'.$row->id.'"';
        $str .= (($row->id==$selected) ? " selected >":">");
        $str .= $row->name." </option>";
      }
  }else {
    $str .= "Gagal memuat table $table";
  }

return $str;

}



//trading
//Trading paper
function get_info_trading($field)
  {
    $ci=& get_instance();
    $query = $ci->db->get_where("trading",['id_trading'=>1])->row();
    return $query->$field;
  }


  function masa_berlaku_paper($waktu_mulai)
{
  $sekarang = date("d-m-Y");
  $masaberlaku = strtotime($waktu_mulai) - strtotime($sekarang);

  return $masaberlaku/(24*60*60);
}
